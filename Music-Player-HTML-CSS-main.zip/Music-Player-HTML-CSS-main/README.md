# Music-Player-HTML-CSS
In this project I created the front-end design of a music player in HTML and CSS.

I have uploaded a total of 4 files here :-
1. MusicPlayerHomePage.html - It consists of the Home Page's html code of the Music Player.
2. MusicPlayerSinglePlaylistScreen.html - It consits of the Single Playlist Screen's html code of the Music Player.
3. MusicPlayerStyle.css - It consists of the styling for both the html pages in CSS.
4. MusicPlayerProject.zip - It is a zip file which consists of all the required images along with the HTML and CSS files for the project to work properly. If you want to view the project, download this file only.


Screenshots of the music player :-

![alt text](https://raw.githubusercontent.com/rajarshisg/Music-Player-HTML-CSS/main/Screenshots/IMG1.PNG)


![alt text](https://raw.githubusercontent.com/rajarshisg/Music-Player-HTML-CSS/main/Screenshots/IMG2.PNG)


![alt text](https://raw.githubusercontent.com/rajarshisg/Music-Player-HTML-CSS/main/Screenshots/IMG3.PNG)
